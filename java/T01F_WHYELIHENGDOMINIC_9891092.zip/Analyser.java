/*
 * Module code: CSIT213
 * Assignment name: Assignment 3
 * UOW student number: 9891092
 * Full name: WHYE LI HENG DOMINIC
 * Tutorial group: T01
 */

import java.util.ArrayList;
import java.util.HashMap;


public interface Analyser {

   
    HashMap<String, Double> analyse(ArrayList<CarparkUsage> data);
}
